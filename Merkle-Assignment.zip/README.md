## TO-FIX

- Need to learn CSS and make it responsive
