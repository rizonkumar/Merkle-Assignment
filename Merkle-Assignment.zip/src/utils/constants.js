export const LOGO_URL =
  "https://assets-eu-01.kc-usercontent.com/27bd3334-62dd-01a3-d049-720ae980f906/b705868e-5a09-420e-882f-043f9d1e31f5/MERKLE%402x.jpeg?q=75&fm=jpg&w=960";
export const LOGO_URL1 =
  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR9foQYBSN50lz6-3ksCh0sqHfaxWIShVDe2e8U4qSnKTIV0ftO1MTT3z0xi-882U7yris&usqp=CAU";
